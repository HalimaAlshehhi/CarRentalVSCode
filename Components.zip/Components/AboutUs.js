import { useState } from "react";

import pic from './logo.jpg';

    const AboutUs = ()=>{
 
    return(
        <div className="AboutUs">
            <center> <img src={pic} width="25%" height="25%"/></center>.

            <h1><center>Welcome to Car Rental</center> </h1>
          
            <h3><center> Where we redefine your journey with seamless and reliable car rental solutions.
         With a commitment to providing exceptional service, we pride ourselves on offering a fleet of 
         vehicles that caters to every need and occasion. </center></h3>

         <center><h3>At Car Rental, we understand that convenience is key.
             Whether you're embarking on a business trip, family vacation, or just need a 
             reliable set of wheels for daily life, we've got you covered. Our diverse range of
             well-maintained vehicles ensures there's something for everyone, from sleek sedans
             to spacious SUVs.</h3></center>

         <center><h3>What sets us apart is our dedication to customer satisfaction.
                 Our team is passionate about delivering a hassle-free experience, ensuring you
                 can focus on the joy of your journey. From easy booking processes to flexible rental
                 durations, we prioritize your comfort and convenience at every step.</h3></center>

                 <center><h3>Safety is at the forefront of our priorities. All our vehicles
                     undergo rigorous inspections to guarantee they meet the highest standards, 
                     providing you with peace of mind as you hit the road. Our commitment to your
                      safety extends beyond the vehicles – we adhere to strict hygiene protocols, 
                      ensuring a clean and sanitized environment for every rental.</h3></center>

                      <h2><center>Thank you for choosing Car Rental, where every mile is a memory waiting to be made!</center> </h2>

          </div>); 
      

  }


    

export default AboutUs;