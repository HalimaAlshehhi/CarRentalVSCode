import React, { useState } from 'react';
import { useNavigate  } from 'react-router-dom';
import { Link } from "react-router-dom";

// Import car images
import Kia from './images/White-Kia.jpeg';
import Toyota from './images/toyota.jpeg';
import Honda from './images/Honda.jpeg';
import Lexus from './images/lexus GX.jpeg';
import Mercedes from './images/mercedes.jpeg';
import Ford from './images/Ford.jpeg';
import Nissan from './images/Nissan.jpeg';
import LandRover from './images/land rover.jpeg';
import Chevrolet from './images/cheverlote.jpeg';

const tableHeaderStyle = {
  backgroundColor: '#f2f2f2',
  fontWeight: 'bold',
  fontSize: '20px',
  border: '5px solid #ddd',
  padding: '8px',
  textAlign: 'center',
};

const tableCellStyle = {
  border: '5px solid #ddd',
  fontWeight: 'bold',
  fontSize: '20px',
  padding: '8px',
  textAlign: 'center',
};


const Cars = () => {
  const navigate  = useNavigate(); // Initialize useNavigate

  // Sample car data with imported images
  const [cars, setCars] = useState([
    { image: Kia, brandname: 'Kia', carsize: 'small', carmodel: 'Picanto', carseats: '5', extras: '122', year: '2019', color: 'White', priceperday: '250', },
    { image: Toyota, brandname: 'Toyota', carsize: 'small', carmodel: 'Yaris', carseats: '5', extras: '117', year: '2020', color: 'Red', priceperday: '150' },
    { image: Honda, brandname: 'Honda', carsize: 'SUV', carmodel: 'CRV', carseats: '5', extras: '135', year: '2017', color: 'Silver', priceperday: '200' },
    { image: Ford, brandname: 'Ford', carsize: 'SUV', carmodel: 'EcoSport', carseats: '5', extras: '167', year: '2021', color: 'White', priceperday: '300' },
    { image: Nissan, brandname: 'Nissan', carsize: 'Large', carmodel: 'Patrol', carseats: '7', extras: '750', year: '2022', color: 'White', priceperday: '400' },
    { image: LandRover, brandname: 'Land Rover', carsize: 'Premium', carmodel: 'Range Rover', carseats: '7', extras: '1800', year: '2022', color: 'Black', priceperday: '700' },
    { image: Chevrolet, brandname: ' Chevrolet', carsize: 'Small', carmodel: 'Malibu', carseats: '5', extras: '205', year: '2016', color: 'Gold', priceperday: '100' },
    { image: Lexus, brandname: ' Lexus', carsize: 'Large', carmodel: 'GX', carseats: '7', extras: '780', year: '2021', color: 'Silver', priceperday: '700' },
    { image: Mercedes, brandname: ' Mercedes', carsize: 'Premium', carmodel: 'Maybach', carseats: '4', extras: '4000', year: '2023', color: 'White', priceperday: '3500' },
  ]);

  const handleSubmit = () => {
    // Handle submit logic here
    console.log('Submit button clicked!');

    // Navigate to the 'orders' page
    navigate('/payments');
  };
 
  return (
    <div>
      <h2 style={{ color: 'black', fontSize: '40px', textAlign: 'center', fontWeight: 'bold' }}>Choose Your Cars</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
  <thead>
    <tr>
      <th></th>
      <th style={tableHeaderStyle}>Choose</th>

      <th style={tableHeaderStyle}>Brand</th>
      <th style={tableHeaderStyle}>Size</th>
      <th style={tableHeaderStyle}>Model</th>
      <th style={tableHeaderStyle}>Seats</th>
      <th style={tableHeaderStyle}>Extras</th>
      <th style={tableHeaderStyle}>Year</th>
      <th style={tableHeaderStyle}>Color</th>
      <th style={tableHeaderStyle}>Price</th>
      <th > images</th>
    </tr>
  </thead>

  <tbody>
    {cars.map((car) => (
      <tr key={car.brandname} >
        
        <td>

        </td>
                <button onClick={handleSubmit}>Add Car</button>
<td style={tableCellStyle}>
          <img src={car.image}  style={{ width: '150px', height: '100px' }} />
        </td>
        <td style={tableCellStyle}>{car.brandname}</td>
        <td style={tableCellStyle}>{car.carsize}</td>
        <td style={tableCellStyle}>{car.carmodel}</td>
        <td style={tableCellStyle}>{car.carseats}</td>
        <td style={tableCellStyle}>{car.extras}</td>
        <td style={tableCellStyle}>{car.year}</td>
        <td style={tableCellStyle}>{car.color}</td>
        <td style={tableCellStyle}>{car.priceperday}</td>
      </tr>
    ))}
  </tbody>
</table>

    </div>
  );
};

export default Cars;