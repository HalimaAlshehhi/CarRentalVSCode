import React from "react"
import { Link } from "react-router-dom";

 function Signup() {
 return (


        <div className='d-flex justify-content-center align-items-center bg-primary vh-100 ›
       
        <div className='bg-white p-3 rounded w-25 >
            <h2> Sign Up </h2>
<form action ="">
<div className="mb-3">
        <label htmlFor="Full name" >Full name </label>
        <br/>
        <input type="name" placeholder="Enter name" className="form-control rounded-0"/>
    </div>
    <div className="mb-3">
    <label htmlFor="Phone Number" >Phone Number </label>
    <br/>
        <input type="PhNo" placeholder="+971 ** *** ****" className="form-control rounded-0"/>
    </div>
    <div className="mb-3">
    <label htmlFor="DOB" >Date of birth </label>
    <br/>
        <input type="DOB" placeholder="dd/mm/yyyy" className="form-control rounded-0"/>
    </div>
    <div className="mb-3">
        <label htmlFor="email" >Email </label>
        <br/>
        <input type="email" placeholder="Enter email" className="form-control rounded-0"/>
    </div>

    <div className="mb-3">
    <label htmlFor="password" >Password </label>
    <br/>
        <input type="password" placeholder="Enter password" className="form-control rounded-0"/>
    </div>
    <br/>
    <Link to= "/Cars" className="">Create account </Link>
    <br/>
    <Link to= "/Login"  className=" "> Log in </Link>

</form>
    </div>
  
    )
}

export default Signup;