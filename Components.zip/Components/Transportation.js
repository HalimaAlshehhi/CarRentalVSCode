import React, { useState } from "react"
import { Link } from "react-router-dom";
import Dropdown from "./Dropdown";

  
 function Transportation() {
 return (
    <div>
 <h2> Please fill in your address for Delivery  </h2>
       <Dropdown />
     
      
   

    <div className='d-flex justify-content-center align-items-center bg-primary vh-100>
       
        <div className='bg-white p-3 rounded w-25 >
           
<form action ="">
<br/>
    <div className="mb-3">
        <label htmlFor="Street Name" >Street Name </label>
        <br/>
        <input type="Street Name" placeholder="Enter Street Name" className="form-control rounded-0"/>
    </div>

    <br/>

    <div className="mb-3">
    <label htmlFor="House Number" >House Number</label>
    <br/>
        <input type="House Number" placeholder="Enter House Number" className="form-control rounded-0"/>
    </div>
    <br/>
    <Link to= "/Payment" className="btn btn-default border w-100 text-decoration-none">Submit </Link>
    <br/>

</form>
    </div>
 
 </div>
    );
 }

export default Transportation;
