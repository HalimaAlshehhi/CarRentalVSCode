import React, { useState } from 'react';

const Dropdown = () => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleDropdownChange = (event) => {
    setSelectedOption(event.target.value);
  };

  return (
    <div>
      <label htmlFor="dropdown">Select City:</label>
      <select id="dropdown" value={selectedOption} onChange={handleDropdownChange}>
        <option value="">Select...</option>
        <option value="Abudhabi">Abudhabi</option>
        <option value="Alain">Alain</option>
        <option value="Dubai">Dubai</option>
        <option value="Sharjah">Sharjah</option>
        <option value="Ajman">Ajman</option>
        <option value="Ras Alkhaima">Ras Alkhaima</option>
        <option value="Umm Alqewain">Umm Alqewain</option>
        <option value="Fujairah">Fujairah</option>

      </select>
      {selectedOption && <p>You selected: {selectedOption}</p>}
    </div>
  );
};

export default Dropdown;
