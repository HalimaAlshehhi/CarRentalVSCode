import { useState } from "react";
import pic from './logo.jpg';
  const Home = ()=>{
 

    return(
        <div className="home">
           <center> <img src={pic} width="35%" height="35%"/></center>.

            <h2  ><center> Book a car near you and<br></br> Drive in minutes! </center> </h2>
         
        </div>);

  } 

 export default Home;